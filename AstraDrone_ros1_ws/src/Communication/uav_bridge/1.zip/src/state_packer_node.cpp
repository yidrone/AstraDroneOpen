/**
 * state_packer_node.cpp
 * 职责：订阅里程计 -> 打包 0x01 协议 -> 发布到 /bridge/tx
 */
#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/UInt8MultiArray.h>
#include <vector>
#include <cstring>

class StatePackerNode {
public:
    StatePackerNode() : nh_("~") {
        pub_tx_ = nh_.advertise<std_msgs::UInt8MultiArray>("/bridge/tx", 10);
        sub_odom_ = nh_.subscribe("/Odometry", 10, &StatePackerNode::odomCallback, this);
    }

private:
    ros::NodeHandle nh_;
    ros::Publisher pub_tx_;
    ros::Subscriber sub_odom_;

    void odomCallback(const nav_msgs::Odometry::ConstPtr& msg) {
        float x = (float)msg->pose.pose.position.x;
        float y = (float)msg->pose.pose.position.y;
        float z = (float)msg->pose.pose.position.z;

        // 构造 0x01 数据包
        std_msgs::UInt8MultiArray tx_msg;
        tx_msg.data.reserve(17);

        // Head
        tx_msg.data.push_back(0xFF);
        tx_msg.data.push_back(0xFE);
        // Len (13)
        tx_msg.data.push_back(13);
        tx_msg.data.push_back(0);
        // Type (0x01)
        tx_msg.data.push_back(0x01);
        
        // Data (x, y, z)
        uint8_t temp[4];
        memcpy(temp, &x, 4); tx_msg.data.insert(tx_msg.data.end(), temp, temp+4);
        memcpy(temp, &y, 4); tx_msg.data.insert(tx_msg.data.end(), temp, temp+4);
        memcpy(temp, &z, 4); tx_msg.data.insert(tx_msg.data.end(), temp, temp+4);

        pub_tx_.publish(tx_msg);
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "state_packer_node");
    StatePackerNode node;
    ros::spin();
    return 0;
}