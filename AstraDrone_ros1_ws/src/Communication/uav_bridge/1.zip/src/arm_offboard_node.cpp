/**
 * arm_offboard_node.cpp
 * 功能：自动解锁并切换到 OFFBOARD 模式，起飞到指定高度并悬停。
 * 解决问题：替代 QGC 手动操作，满足 PX4 切换 OFFBOARD 需先发送 Setpoint 的机制。
 */

#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>

mavros_msgs::State current_state;

// 回调函数：获取无人机当前状态
void state_cb(const mavros_msgs::State::ConstPtr& msg){
    current_state = *msg;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "arm_offboard_node");
    ros::NodeHandle nh("~");

    // 获取参数：起飞高度，默认 1.5 米
    float takeoff_height;
    nh.param<float>("height", takeoff_height, 1.5);

    // 订阅状态
    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>
            ("/mavros/state", 10, state_cb);
    
    // 发布位置设定点 (必须持续发布，否则无法切换 Offboard)
    ros::Publisher local_pos_pub = nh.advertise<geometry_msgs::PoseStamped>
            ("/mavros/setpoint_position/local", 10);
    
    // 服务客户端
    ros::ServiceClient arming_client = nh.serviceClient<mavros_msgs::CommandBool>
            ("/mavros/cmd/arming");
    ros::ServiceClient set_mode_client = nh.serviceClient<mavros_msgs::SetMode>
            ("/mavros/set_mode");

    // 等待 MAVROS 连接飞控
    ros::Rate rate(20.0);
    while(ros::ok() && !current_state.connected){
        ros::spinOnce();
        rate.sleep();
        ROS_INFO_THROTTLE(1, "Waiting for FCU connection...");
    }

    // 设置目标点 (原地起飞到指定高度)
    geometry_msgs::PoseStamped pose;
    pose.header.frame_id = "map"; // 或 odom，视配置而定
    pose.pose.position.x = 0;
    pose.pose.position.y = 0;
    pose.pose.position.z = takeoff_height;
    pose.pose.orientation.w = 1.0; // 无旋转

    // --- 关键步骤 1: 发送一些设定点 ---
    // 在切换模式前，必须先发送一段时间的设定点
    ROS_INFO("Sending setpoints before mode switch...");
    for(int i = 100; ros::ok() && i > 0; --i){
        local_pos_pub.publish(pose);
        ros::spinOnce();
        rate.sleep();
    }

    // 准备服务请求
    mavros_msgs::SetMode offb_set_mode;
    offb_set_mode.request.custom_mode = "OFFBOARD";

    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = true;

    ros::Time last_request = ros::Time::now();

    ROS_INFO("Start Arming and Offboard sequence...");

    while(ros::ok()){
        // 持续发布位置设定点 (必须放在循环内！)
        // 更新时间戳
        pose.header.stamp = ros::Time::now();
        local_pos_pub.publish(pose);

        // --- 关键步骤 2: 状态机逻辑 ---
        
        // 1. 先解锁 (如果未解锁)
        if( !current_state.armed && (ros::Time::now() - last_request > ros::Duration(5.0))){
            if( arming_client.call(arm_cmd) && arm_cmd.response.success){
                ROS_INFO("Vehicle armed");
            }else{
                ROS_WARN("Arming failed, retrying...");
            }
            last_request = ros::Time::now();
        }
        // 2. 解锁成功后，切换 OFFBOARD (如果当前不是 OFFBOARD)
        else if( current_state.armed && current_state.mode != "OFFBOARD" &&
            (ros::Time::now() - last_request > ros::Duration(5.0))){
            
            if( set_mode_client.call(offb_set_mode) && offb_set_mode.response.mode_sent){
                ROS_INFO("Offboard enabled");
            }else{
                ROS_WARN("Offboard switch failed, retrying...");
            }
            last_request = ros::Time::now();
        }
        
        // 3. 监控状态
        if(current_state.armed && current_state.mode == "OFFBOARD") {
            ROS_INFO_THROTTLE(5, "Status: ARMED & OFFBOARD. Hovering at %.2fm", takeoff_height);
        }

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}