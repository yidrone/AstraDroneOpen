/**
 * px4_unlocker_node.cpp
 * 职责：
 * 1. 持续发布 Position Setpoint (骗过 PX4 的 Failsafe)
 * 2. 负责 OFFBOARD 切换和 ARM 解锁的时序控制
 */

#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>
#include <std_srvs/Trigger.h>
#include <atomic>
#include <thread>

class Px4Unlocker {
public:
    Px4Unlocker() : nh_("~") {
        // MAVROS 接口
        state_sub_ = nh_.subscribe<mavros_msgs::State>("/mavros/state", 10, &Px4Unlocker::stateCb, this);
        local_pos_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/mavros/setpoint_position/local", 10);
        arming_client_ = nh_.serviceClient<mavros_msgs::CommandBool>("/mavros/cmd/arming");
        set_mode_client_ = nh_.serviceClient<mavros_msgs::SetMode>("/mavros/set_mode");

        // 本节点提供的服务
        unlock_server_ = nh_.advertiseService("/bridge/unlock_uav", &Px4Unlocker::unlockCb, this);
        land_server_ = nh_.advertiseService("/bridge/land_uav", &Px4Unlocker::landCb, this);

        // 启动数据流线程 (默认不发，触发后开始发)
        is_streaming_ = false;
        stream_thread_ = std::thread(&Px4Unlocker::streamLoop, this);

        ROS_INFO("PX4 Unlocker Node Ready. Service: /bridge/unlock_uav");
    }

    ~Px4Unlocker() {
        is_streaming_ = false;
        if (stream_thread_.joinable()) stream_thread_.join();
    }

private:
    ros::NodeHandle nh_;
    ros::Subscriber state_sub_;
    ros::Publisher local_pos_pub_;
    ros::ServiceClient arming_client_;
    ros::ServiceClient set_mode_client_;
    ros::ServiceServer unlock_server_;
    ros::ServiceServer land_server_;

    mavros_msgs::State current_state_;
    std::atomic<bool> is_streaming_;
    std::thread stream_thread_;

    void stateCb(const mavros_msgs::State::ConstPtr& msg) {
        current_state_ = *msg;
    }

    // 核心线程：以 20Hz 频率发送悬停点
    void streamLoop() {
        ros::Rate rate(20.0);
        while (ros::ok()) {
            if (is_streaming_) {
                geometry_msgs::PoseStamped pose;
                pose.header.stamp = ros::Time::now();
                pose.header.frame_id = "map";
                // 悬停在 1.0 米高度
                pose.pose.position.x = 0;
                pose.pose.position.y = 0;
                pose.pose.position.z = 1.0; 
                pose.pose.orientation.w = 1.0;

                local_pos_pub_.publish(pose);
            }
            rate.sleep();
        }
    }

    // 解锁服务回调
    bool unlockCb(std_srvs::Trigger::Request& req, std_srvs::Trigger::Response& res) {
        ROS_INFO("Received Unlock Request...");

        // 1. 等待与飞控连接
        if (!current_state_.connected) {
            res.success = false;
            res.message = "FCU Not Connected!";
            ROS_ERROR("%s", res.message.c_str());
            return true;
        }

        // 2. 开启数据流 (关键！)
        is_streaming_ = true;
        ROS_INFO("Setpoint Stream Started. Waiting 2s...");
        
        // 3. 等待数据流稳定 (2秒)
        ros::Duration(2.0).sleep();

        // 4. 切换 OFFBOARD
        mavros_msgs::SetMode offb_set_mode;
        offb_set_mode.request.custom_mode = "OFFBOARD";
        
        if (set_mode_client_.call(offb_set_mode) && offb_set_mode.response.mode_sent) {
            ROS_INFO("Offboard enabled");
        } else {
            res.success = false;
            res.message = "Failed to set OFFBOARD";
            ROS_ERROR("%s", res.message.c_str());
            // 注意：这里不停止流，再试一次可能就成了
            return true;
        }

        // 5. 解锁
        mavros_msgs::CommandBool arm_cmd;
        arm_cmd.request.value = true;

        if (arming_client_.call(arm_cmd) && arm_cmd.response.success) {
            ROS_INFO("Vehicle ARMED");
            res.success = true;
            res.message = "Unlocked & Hovering at 1m";
        } else {
            res.success = false;
            res.message = "Arming Failed (Check Battery/GPS?)";
            ROS_ERROR("%s", res.message.c_str());
        }

        return true;
    }

    // 降落服务回调 (停止流并降落)
    bool landCb(std_srvs::Trigger::Request& req, std_srvs::Trigger::Response& res) {
        // 停止悬停流，否则降落模式可能会被覆盖或冲突
        // (注：实际上 AUTO.LAND 优先级较高，但停止流更安全)
        is_streaming_ = false; 

        mavros_msgs::SetMode land_mode;
        land_mode.request.custom_mode = "AUTO.LAND";
        if (set_mode_client_.call(land_mode) && land_mode.response.mode_sent) {
            res.success = true;
            res.message = "Landing...";
        } else {
            res.success = false;
            res.message = "Land Fail";
        }
        return true;
    }
};

int main(int argc, char **argv) {
    ros::init(argc, argv, "px4_unlocker_node");
    Px4Unlocker node;
    ros::spin();
    return 0;
}