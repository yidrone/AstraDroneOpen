/**
 * command_parser_node.cpp
 * 职责：订阅 /bridge/rx -> 解析协议 -> 在新终端中调用脚本 (Debug模式)
 * 修改点：使用 gnome-terminal 显式弹出窗口运行脚本，方便调试报错
 */
#include <ros/ros.h>
#include <std_msgs/UInt8MultiArray.h>
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream>
#include <cstring>
#include <iomanip>

class CommandParserNode {
public:
    CommandParserNode() : nh_("~") {
        sub_rx_ = nh_.subscribe("/bridge/rx", 100, &CommandParserNode::rxCallback, this);
        
        // 脚本路径
        nh_.param<std::string>("script_path", script_path_, "/home/orinnano/scripts/");
        if (script_path_.back() != '/') script_path_ += "/";

        // YAML 路径
        nh_.param<std::string>("yaml_path", yaml_path_, "");

        ROS_INFO("Command Parser Ready (Debug Mode).");
        ROS_INFO("  Script Path: %s", script_path_.c_str());
        ROS_INFO("  Target YAML: %s", yaml_path_.c_str());
    }

private:
    ros::NodeHandle nh_;
    ros::Subscriber sub_rx_;
    std::string script_path_;
    std::string yaml_path_;
    std::vector<uint8_t> buffer_;

    void rxCallback(const std_msgs::UInt8MultiArray::ConstPtr& msg) {
        buffer_.insert(buffer_.end(), msg->data.begin(), msg->data.end());
        processBuffer();
    }

    void processBuffer() {
        while (buffer_.size() >= 5) { 
            if (buffer_[0] != 0xFF || buffer_[1] != 0xFE) {
                buffer_.erase(buffer_.begin()); continue;
            }
            
            uint16_t data_len = buffer_[2] | (buffer_[3] << 8);
            uint16_t total_pkt_len = 4 + data_len; 

            if (buffer_.size() < total_pkt_len) break; 

            std::vector<uint8_t> payload(buffer_.begin() + 4, buffer_.begin() + total_pkt_len);
            processPayload(payload);
            buffer_.erase(buffer_.begin(), buffer_.begin() + total_pkt_len);
        }
    }

    // --- 优化后的极简版：直接在新终端运行脚本 ---
    void runScriptInTerminal(const std::string& script_name, const std::string& args = "") {
        // 1. 拼接脚本的全路径 (例如: /home/user/scripts/run_sh/ctrl.sh)
        std::string full_path = script_path_ + script_name;

        // 2. 构造最简单的系统命令
        // 格式: gnome-terminal -- /path/to/script.sh arg1
        // 说明: 
        //   -- 表示后面的参数是命令而非终端选项
        //   如果担心没有 +x 权限，也可以写成: "gnome-terminal -- bash " + full_path + " " + args
        std::string cmd = "gnome-terminal -- " + full_path + " " + args;

        ROS_INFO("Launching: %s", cmd.c_str());
        
        // 3. 执行
        int ret = system(cmd.c_str());
        if (ret != 0) ROS_WARN("Failed to launch terminal for %s", script_name.c_str());
    }

    void processPayload(const std::vector<uint8_t>& payload) {
        if (payload.empty()) return;
        uint8_t type = payload[0]; 
        const uint8_t* data = payload.data() + 1; 

        switch (type) {
            // Task: 自动飞行航点 (0x02)
            case 0x02: { 
                int count = data[0]; 
                ROS_INFO("CMD 0x02: Received %d Waypoints", count);
                if (writeWaypointsToYaml(data, payload.size() - 1)) {
                    runScriptInTerminal("patrol_sim.sh");
                }
                break;
            }
            // Task: 指定位置飞行 (0x03)
            case 0x03: {
                float x, y, z;
                memcpy(&x, data, 4); memcpy(&y, data+4, 4); memcpy(&z, data+8, 4);
                std::stringstream args; args << x << " " << y << " " << z;
                runScriptInTerminal("fly_to.sh", args.str());
                break;
            }
            // Task: 移动指令
            case 0x04: runScriptInTerminal("move.sh", "forward"); break;
            case 0x05: runScriptInTerminal("move.sh", "backward"); break;
            case 0x06: runScriptInTerminal("move.sh", "right"); break;
            case 0x07: runScriptInTerminal("move.sh", "left"); break;
            
            // Task: 控制指令
            case 0x08: {
                float val; memcpy(&val, data, 4);
                std::stringstream args; args << "yaw " << val;
                runScriptInTerminal("pose.sh", args.str());
                break;
            }
            case 0x09: {
                float val; memcpy(&val, data, 4);
                std::stringstream args; args << "height " << val;
                runScriptInTerminal("pose.sh", args.str());
                break;
            }
            case 0x0a: {
                float val; memcpy(&val, data, 4);
                std::stringstream args; args << "yaw " << val;
                runScriptInTerminal("gimbal.sh", args.str());
                break;
            }
            case 0x0b: {
                float val; memcpy(&val, data, 4);
                std::stringstream args; args << "pitch " << val;
                runScriptInTerminal("gimbal.sh", args.str());
                break;
            }
            case 0x0c: {
                float val; memcpy(&val, data, 4);
                std::stringstream args; args << "exposure " << val;
                runScriptInTerminal("camera.sh", args.str());
                break;
            }
            // Task: 系统指令
            case 0x0d: { // 启动
                ROS_INFO("CMD 0x0D: Start UAV");
                runScriptInTerminal("com.sh"); 
                break;
            }
            case 0x0e: { // 解锁
                ROS_INFO("CMD 0x0E: Unlock UAV");
                runScriptInTerminal("ctrl.sh", "0");
                break;
            }
            
            default:
                ROS_WARN("Unknown CMD Type: 0x%02X", type);
        }
    }

    bool writeWaypointsToYaml(const uint8_t* data, size_t len) {
        if (yaml_path_.empty()) return false;
        int count = data[0];
        std::ofstream yaml_file(yaml_path_);
        if (!yaml_file.is_open()) {
            ROS_ERROR("Failed to open YAML file: %s", yaml_path_.c_str());
            return false;
        }

        yaml_file << "# Auto-generated by uav_bridge\n";
        yaml_file << "# Pointmode: 0=Takeoff, 1=Detect, 2=Nothing, 3=Land\n";
        yaml_file << "waypoints:\n";

        int offset = 1; 
        for(int i=0; i<count; i++) {
            if (offset + 21 > len + 1) break;
            uint8_t index = data[offset]; offset += 1;
            float x, y, z, pitch, yaw;
            memcpy(&x, data+offset, 4); offset+=4;
            memcpy(&y, data+offset, 4); offset+=4;
            memcpy(&z, data+offset, 4); offset+=4;
            memcpy(&pitch, data+offset, 4); offset+=4;
            memcpy(&yaw, data+offset, 4); offset+=4;

            std::string mode = "Detect_point";
            if (i == 0) mode = "Takeoff_point";
            else if (i == count - 1) mode = "Land_point";

            yaml_file << std::fixed << std::setprecision(2);
            yaml_file << "  - {x: " << x << ", y: " << y << ", z: " << z 
                      << ", yaw: " << yaw << ", pointmode: \"" << mode << "\"}\n";
        }

        // 写入静态参数
        yaml_file << "\nland_height: 0.2\npx4_max_distance: 1.0\nmax_yaw_change: 0.2\n\n";
        yaml_file << "threshould: \n  takeoff_threshould: 0.3\n  waypoint_threshould: 0.3\n";
        yaml_file << "  aligning_threshould: 0.15\n  landing_threshould: 0.15\n  arrive_yaw_threshould: 0.3\n";
        yaml_file << "  times_detect_threshould: 40\n  waypoint_adjust_max_second_threshould: 5\n";
        yaml_file << "  land_adjust_max_second_threshould: 10\n  planner_min_pub_threshould: 0.025\n\n";
        yaml_file << "switch:\n flag_planner_px4: 0\n flag_landing_detect: 0\n auto_land: 1\n";

        yaml_file.close();
        ROS_INFO("Generated YAML with %d waypoints.", count);
        return true;
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "command_parser_node");
    CommandParserNode node;
    ros::spin();
    return 0;
}