/**
 * rtsp_sender_node.cpp
 * 功能：订阅 ROS 图像话题，使用 Orin 硬件加速编码 (H.264)，推送到 RTSP 服务器。
 * 规格：支持 1920x1080 @ 30Hz
 */

#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/opencv.hpp>

class RtspSenderNode {
public:
    RtspSenderNode() : nh_("~") {
        // --- 1. 获取参数 ---
        std::string topic_name;
        std::string rtsp_url;
        int fps, width, height;
        int bitrate;
        
        // 默认参数
        nh_.param<std::string>("topic_input", topic_name, "/camera/image_raw");
        nh_.param<std::string>("rtsp_url", rtsp_url, "rtsp://127.0.0.1:8554/stream");
        nh_.param<int>("fps", fps, 30);           // 协议要求 30Hz
        nh_.param<int>("width", width, 1920);     // 协议要求 1920
        nh_.param<int>("height", height, 1080);   // 协议要求 1080
        nh_.param<int>("bitrate", bitrate, 4000000); // 4Mbps 码率，保证清晰度

        ROS_INFO("RTSP Node Started.");
        ROS_INFO("  Target: %dx%d @ %d FPS", width, height, fps);
        ROS_INFO("  Source Topic: %s", topic_name.c_str());
        ROS_INFO("  RTSP URL: %s", rtsp_url.c_str());

        // --- 2. 构建 GStreamer 管道 ---
        // 核心：appsrc (输入) -> nvv4l2h264enc (NVIDIA硬件编码) -> rtspclientsink (RTSP推流)
        std::stringstream ss;
        ss << "appsrc ! "
           << "autovideoconvert ! "
           // 强制转换输入格式和分辨率
           << "video/x-raw, format=(string)I420, width=(int)" << width << ", height=(int)" << height << ", framerate=(fraction)" << fps << "/1 ! " 
           // NVIDIA 硬件编码器参数配置
           << "nvv4l2h264enc bitrate=" << bitrate << " insert-sps-pps=true preset-level=1 ! " 
           << "video/x-h264, stream-format=byte-stream ! "
           << "h264parse ! "
           // 推流到 RTSP 服务器
           << "rtspclientsink location=" << rtsp_url << " protocols=tcp";

        gst_pipeline_ = ss.str();
        writer_fps_ = fps;
        target_size_ = cv::Size(width, height);

        // --- 3. 订阅图像 ---
        image_transport::ImageTransport it(nh_);
        sub_image_ = it.subscribe(topic_name, 1, &RtspSenderNode::imageCallback, this);
    }

    ~RtspSenderNode() {
        if (writer_.isOpened()) {
            writer_.release();
        }
    }

private:
    ros::NodeHandle nh_;
    image_transport::Subscriber sub_image_;
    cv::VideoWriter writer_;
    std::string gst_pipeline_;
    int writer_fps_;
    cv::Size target_size_;

    void imageCallback(const sensor_msgs::ImageConstPtr& msg) {
        cv_bridge::CvImagePtr cv_ptr;
        try {
            // 将 ROS 图像消息转为 OpenCV Mat (BGR8 格式)
            cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
        } catch (cv_bridge::Exception& e) {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }

        // 检查输入图像尺寸是否符合要求，如果不符则进行缩放
        cv::Mat frame_to_send;
        if (cv_ptr->image.size() != target_size_) {
            cv::resize(cv_ptr->image, frame_to_send, target_size_);
        } else {
            frame_to_send = cv_ptr->image;
        }

        // --- 延迟初始化 GStreamer 管道 ---
        if (!writer_.isOpened()) {
            // 打开管道，指定 API 后端为 GStreamer
            if (!writer_.open(gst_pipeline_, cv::CAP_GSTREAMER, 0, writer_fps_, target_size_, true)) {
                ROS_ERROR_THROTTLE(5.0, "Failed to open GStreamer pipeline!");
                ROS_ERROR_THROTTLE(5.0, "Pipeline: %s", gst_pipeline_.c_str());
                return;
            }
            ROS_INFO("GStreamer pipeline initialized successfully.");
        }

        // --- 推流 ---
        if (writer_.isOpened()) {
            writer_.write(frame_to_send);
        }
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "rtsp_sender_node");
    RtspSenderNode node;
    ros::spin();
    return 0;
}