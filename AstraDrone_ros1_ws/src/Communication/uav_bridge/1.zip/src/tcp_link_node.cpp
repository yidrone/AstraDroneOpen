/**
 * tcp_link_node.cpp
 * 职责：维护 TCP 9527 连接，实现 ROS Topic <--> TCP Stream 的透传
 */
#include <ros/ros.h>
#include <std_msgs/UInt8MultiArray.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <thread>
#include <vector>
#include <mutex>

class TcpLinkNode {
public:
    TcpLinkNode() : nh_("~") {
        nh_.param<int>("port", port_, 9527);

        // 内部通信接口
        pub_rx_ = nh_.advertise<std_msgs::UInt8MultiArray>("/bridge/rx", 100);
        sub_tx_ = nh_.subscribe("/bridge/tx", 100, &TcpLinkNode::txCallback, this);

        ROS_INFO("TCP Link Node Init. Port: %d", port_);
        server_thread_ = std::thread(&TcpLinkNode::serverLoop, this);
    }

private:
    ros::NodeHandle nh_;
    ros::Publisher pub_rx_;
    ros::Subscriber sub_tx_;
    std::thread server_thread_;
    int port_;
    
    int client_fd_ = -1;
    std::mutex sock_mutex_;

    // --- 发送回调：收到 ROS 内部数据 -> 发送给 TCP 客户端 ---
    void txCallback(const std_msgs::UInt8MultiArray::ConstPtr& msg) {
        std::lock_guard<std::mutex> lock(sock_mutex_);
        if (client_fd_ < 0) return;

        ssize_t sent = send(client_fd_, msg->data.data(), msg->data.size(), MSG_NOSIGNAL);
        if (sent < 0) {
            ROS_ERROR("Send failed, client maybe disconnected.");
            close(client_fd_);
            client_fd_ = -1;
        }
    }

    // --- 接收循环：收到 TCP 数据 -> 发布到 ROS 内部 ---
    void serverLoop() {
        int server_fd = socket(AF_INET, SOCK_STREAM, 0);
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(port_);
        
        int opt = 1;
        setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        bind(server_fd, (struct sockaddr*)&addr, sizeof(addr));
        listen(server_fd, 5);

        while (ros::ok()) {
            ROS_INFO("Waiting for connection...");
            int new_fd = accept(server_fd, nullptr, nullptr);
            if (new_fd < 0) continue;

            ROS_INFO("Client Connected!");
            {
                std::lock_guard<std::mutex> lock(sock_mutex_);
                if (client_fd_ != -1) close(client_fd_);
                client_fd_ = new_fd;
            }

            // 接收循环
            uint8_t buf[1024];
            while (ros::ok()) {
                ssize_t len = recv(client_fd_, buf, sizeof(buf), 0);
                if (len <= 0) break; // 断开

                // 转发给解析节点
                std_msgs::UInt8MultiArray rx_msg;
                rx_msg.data.assign(buf, buf + len);
                pub_rx_.publish(rx_msg);
            }

            ROS_WARN("Client Disconnected.");
            close(client_fd_);
            client_fd_ = -1;
        }
        close(server_fd);
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "tcp_link_node");
    TcpLinkNode node;
    ros::spin();
    return 0;
}